"""HSL color class."""
