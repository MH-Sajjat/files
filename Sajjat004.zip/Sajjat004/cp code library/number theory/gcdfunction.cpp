#include<iostream>
#include<algorithm>
using namespace std;
int main()
{
	int n,i;
	cin >>n;
	int a[n];
	for (int i = 0; i < n; ++i)
	{
		cin >> a[i];
	}
	sort(a,a+n);
	if(binary_search(a,a+n,9))
		cout <<"found\n";
	else
		cout <<"not found\n";
	return 0;
}