/*..............Bismillahir Rahmanir Rahim.............*/
/**
*     => Md. Sajjat Hosen
*     => Department of Computer Science and Engineering
*     => Bangabandhu Sheikh Mujibur Rahman Science and Technology University
**/

/*..................! TRY ONCE MORE !..................*/

#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace std ;
using namespace __gnu_pbds ;

typedef long long               ll ;
typedef long double             ld ;
typedef unsigned long long      ull ;
typedef pair<int,int>           pii ;
typedef pair<ll,ll>             pll ;
typedef vector<int>             vi ;
typedef vector<ll>              vll ;
typedef vector<vector<int>>     vvi ;
typedef tree <int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update > ordered_set ;
typedef tree <int, null_type, less_equal<int>, rb_tree_tag, tree_order_statistics_node_update > ordered_multiset ;

inline int Int(){int x ; scanf("%d",&x) ; return x ;}
inline ll Long(){ll x ; scanf("%lld",&x) ; return x ;}
inline float Float(){float x ; scanf("%f",&x) ; return x ;}
inline double Double(){double x ; scanf("%lf",&x); return x;}

#define error(args...) { string _s = #args; replace(_s.begin(), _s.end(), ',', ' '); stringstream _ss(_s); istream_iterator<string> _it(_ss); err(_it, args); }
void err(istream_iterator<string> it) {cout << endl ;}
template<typename T, typename... Args>
void err(istream_iterator<string> it, T a, Args... args) {
    cerr << *it << " = " << a << ' ' ;
    err(++it, args...);
}

//   Moves : L, U, R, D, LU, RU, RD, LD.
int dx[8] = {0, -1, 0, 1, -1, -1, 1, 1} ;
int dy[8] = {-1, 0, 1, 0, -1, 1, 1, -1} ;

const int N          = (int)2e5 + 5 ;
const int maxN       = (int)1e6 + 6 ;
const ll  Mod        = (ll)1e9 + 7 ;
const int inf        = (int)2e9 ;
const ll  Inf        = (ll)1e18 ;

#define     debug(x)    cerr << #x << " = " << x << '\n' ;
#define     rep(i,b,e)  for(__typeof(e) i = (b) ; i != (e + 1) - 2 * ((b) > (e))  ; i += 1 - 2 * ((b) > (e)))
#define     Int         Int()
#define     Long        Long()
#define     Float       Float()
#define     Double      Double()
#define     all(x)      x.begin() , x.end()
#define     sz(x)       (int)x.size()
#define     ff          first
#define     ss          second
#define     pb          push_back
#define     eb          emplace_back
#define     mp          make_pair
#define     TN          typename
#define     mem(a)      memset(a , 0 ,sizeof a)
#define     memn(a)     memset(a , -1 ,sizeof a)
#define     pie         acos(-1.0)
#define     nl          '\n'
#define     Fast_Read   ios_base::sync_with_stdio(false); cin.tie(nullptr);  cout.tie(nullptr);

template <TN T> T gcd(T a, T b) { return !b ? a : gcd(b, a % b); }
template <TN T> T lcm(T a, T b) { return a * (b / gcd(a, b)); }

/*............ ! Code start from here ! ............*/

int a[N], compressed[N];
map < ll, ll > m;

void maping(int n){
	int assign = 0, idx = 0, x;
	for(int i = 0; i < n; i++){
		x = a[i];
		if(m.find(x) == m.end()){
			m[x] = assign;
			assign++;
		}
		compressed[idx++] = m[x];
	}
}

void print_compressed_array(int n){
	for(int i = 0; i < n; i++)
		printf("%d ", compressed[i]);
}

int main(){
    //Fast_Read
    //freopen("input.txt","r",stdin);
    int test = 1 , tc = 0 ;
    int n;
    while(test--){
        n = Int;
        for(int i = 0; i < n; i++){
        	a[i] = Int;
        }
        // if you needed to sort, sort the input array before process
        maping(n);
        print_compressed_array(n);
    }
    return 0 ;
}

/*...............END................*/