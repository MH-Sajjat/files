#include <bits/stdc++.h>
using namespace std;

typedef long long           ll;
typedef long double         ld;
typedef unsigned long long  ull;
typedef pair <int, int>     pii;
typedef pair <ll, ll>       pll;
typedef vector <int>        vi;
typedef vector <ll>         vll;

const int N       = (int) 2e5 + 5;
const int mxN     = (int) 1e6 + 6;
const int MOD     = (int) 1e9 + 7;
const int INF     = (int) 1e9 + 9;
const double EPS  = (double) 1e-9;

#define debug(x)  cerr << #x << " = " << x << '\n';
#define all(x)    x.begin(), x.end()
#define szof(x)   (int) x.size()
#define ff        first
#define ss        second
#define pb        push_back
#define mp        make_pair
#define PI        acos(-1.0)
#define nl        '\n'
#define Fast_IO   ios_base::sync_with_stdio(false); cin.tie(0);

/*........................ let's try one more time ........................*/

map<ll, vi> m;
map<ll, bool> used;

void factorization(ll n) {
  ll idx = n;
  for (ll i = 2; i * i <= n; ++i) {
    if (n % i == 0) {
      m[idx].push_back(i);
      while (n % i == 0) n /= i;
    }
  }
  if (n > 1) m[idx].push_back(n);
  used[idx] = 1;
}

int main() {
#ifdef LOCAL
  freopen("input.txt", "r", stdin);
  // freopen("output.txt", "w", stdout);
#endif
  Fast_IO
  int test = 1, tc = 0;
  cin >> test;
  while (test--) {
    int n; cin >> n;
    set<ll> res;
    for (int i = 1; i <= n; ++i) {
      ll x; cin >> x;
      if (!used[x]) factorization(x);
      for (auto y : m[x]) res.insert(y);
    }
    cout << "Case " << ++tc << ": " << szof(res) << nl;
    for (auto x : res) cout << x << nl;
  }
  return 0;
}