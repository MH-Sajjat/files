#include <bits/stdc++.h>
using namespace std;

typedef long long           ll;
typedef long double         ld;
typedef unsigned long long  ull;
typedef pair <int, int>     pii;
typedef pair <ll, ll>       pll;
typedef vector <int>        vi;
typedef vector <ll>         vll;

const int N       = (int) 1e6 + 5;
const int mxN     = (int) 1e6 + 6;
const int MOD     = (int) 1e9 + 7;
const int INF     = (int) 1e9 + 9;
const double EPS  = (double) 1e-9;

#define debug(x)  cerr << #x << " = " << x << '\n';
#define all(x)    x.begin(), x.end()
#define szof(x)   (int) x.size()
#define ff        first
#define ss        second
#define pb        push_back
#define mp        make_pair
#define PI        acos(-1.0)
#define nl        '\n'
#define Fast_IO   ios_base::sync_with_stdio(false); cin.tie(0);

/*........................ let's try one more time ........................*/

bool isOn(int n, int at) { return (bool) (n & (1 << at)); }
int bitOn(int n, int at) { return n = n | (1 << at); }

int vis[(N >> 5) + 2];
vi prime;

// complexity O(nloglogn)
void bitwiseSieve() {
    vis[1 >> 5] = bitOn(vis[1 >> 5], 1 & 31);
    for (int i = 4; i <= N; i += 2) {
        vis[i >> 5] = bitOn(vis[i >> 5], i & 31);
    }
    for (int i = 3; i * i <= N; i += 2) {
        if (!isOn(vis[i >> 5], i & 31)) {
            for (int j = i * i; j <= N; j += (2 * i)) {
                vis[j >> 5] = bitOn(vis[j >> 5], j & 31);
            }
        }
    }
    for (int i = 2; i <= N; ++i) {
        if (!isOn(vis[i >> 5], i & 31)) {
            prime.pb(i);
        }
    }
}

int main() {
#ifdef LOCAL
  freopen("input.txt", "r", stdin);
  // freopen("output.txt", "w", stdout);
#endif
  Fast_IO
  int test = 1, tc = 0;
  cin >> test;
  bitwiseSieve();
  while (test--) {
    int n; cin >> n;
    vll v(n, 0);
    for (auto& x : v) cin >> x;
    set<int> res;
    // cout << szof(prime) << nl;
    for (auto x : v) {
      for (auto p : prime) {
        if (1LL * p * p > x) break;
        if (x % p == 0) {
          res.insert(p);
          while(x % p == 0) x /= p;
        }
      }
      if (x > 1) res.insert(x);
    }
    cout << "Case #" << ++tc << ": " << szof(res) << nl;
    for (auto x : res) cout << x << nl;
  }
  return 0;
}